<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.7.2
 * checked by: Al-amin
 */

return array('2.0.0', 'Content Elements', true, 'fab fa-contao', false);
