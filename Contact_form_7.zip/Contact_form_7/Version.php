<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked by Richard
 */

return array('2.0.0', '3rd Party Widgets', true, 'fas fa-id-card-alt', true);
