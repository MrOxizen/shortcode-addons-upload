<?php

/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  Checked
 */

return array('2.0.0', 'Marketing Elements', true, 'fas fa-exclamation-circle');
