<?php

namespace OXI_IMAGE_HOVER_UPLOADS\Button\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_IMAGE_HOVER_UPLOADS\Button\Modules as Modules;

class Effects1 extends Modules {
    
}
