<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  Created By Sabibur Rahman
  Date 07/01/2020
 */ 
return array('2.0.0', 'Marketing Elements', true, 'fas fa-qrcode', true);