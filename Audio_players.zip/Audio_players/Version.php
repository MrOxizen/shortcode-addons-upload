<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  checked by al-amin
 */

return array('2.0.0', 'Dynamic Contents', true,'fas fa-volume-up', true);
