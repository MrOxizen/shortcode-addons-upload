<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked by - Al-amin
 */

return array('2.0.0', 'Dynamic Contents', true, 'fas fa-chart-pie', true);
