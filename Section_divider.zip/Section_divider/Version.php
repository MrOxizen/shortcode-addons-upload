<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  Edit & Checked By Sabibur Rahman
 */

return array('2.0.1', 'Extensions', true, 'fas fa-puzzle-piece');
