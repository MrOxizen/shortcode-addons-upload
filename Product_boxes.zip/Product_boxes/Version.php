<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked By Al-amin
 */

return array('2.0.0', 'Marketing Elements', true, 'fab fa-product-hunt');
