<?php

/**
 * APIs.
 *
 * @package LFE
 */

namespace SHORTCODEADDONS;

defined('ABSPATH') || exit;

/**
 * Handle Remote API requests.
 *
 * @package SAEL
 */
class Shortcode_Remote {

    protected static $lfe_instance = NULL;

    const TRANSIENT_CATEGORY = 'shortcode_addons_elements';
    const TRANSIENT_MENU = 'shortcode_addons_menu';
    const CATEGORIES = 'https://www.shortcode-addons.com/wp-json/shortcode-elementor/v1/elements';

    public function __construct() {
        
    }

    /**
     * Access plugin instance. You can create further instances by calling
     */
    public static function shortcode_get_instance() {
        if (NULL === self::$lfe_instance)
            self::$lfe_instance = new self;

        return self::$lfe_instance;
    }

    /**
     * Get a templates categories.
     * @return mixed|\WP_Error
     */
    public function categories_list($force_update = TRUE) {
        $response = get_transient(self::TRANSIENT_CATEGORY);

        if (!$response || $force_update) {

            $request = wp_remote_request(self::CATEGORIES);
            if (!is_wp_error($request)) {
                $response = json_decode(wp_remote_retrieve_body($request), true);
                set_transient(self::TRANSIENT_CATEGORY, $response, 10 * DAY_IN_SECONDS);
            } else {
                $response = $request->get_error_message();
            }
        }
        return $response;
    }

    public function shortcode_addons_menu($force_update = TRUE) {
        $response = get_transient(self::TRANSIENT_MENU);
        if (!$response || $force_update) {
            $directory = OxiAddonsCustomData;
            $DIRfiles = glob($directory . '*', GLOB_ONLYDIR);
            $response = array(
                'Library' => array(
                    'Elements' => array(
                        'name' => 'Elements',
                        'homepage' => 'oxi-addons'
                    ),
                    'import library' => array(
                        'name' => 'import library',
                        'homepage' => 'oxi-addons-import'
                    ),
                    'import style' => array(
                        'name' => 'import style',
                        'homepage' => 'oxi-addons-import-data'
                    )
                )
            );
            if (count($DIRfiles) > 0) {
                foreach ($DIRfiles as $value) {
                    $file = explode('/OxiAddonsCustomData/', $value);
                    if (!empty($value)) {
                        if ($file[1] == 'elementor_templates') {
                            $response['Elementor']['blocks'] = array(
                                'name' => 'blocks',
                                'homepage' => 'oxi-addons-el-template&saetype=blocks'
                            );
                            $response['Elementor']['pre-design'] = array(
                                'name' => 'pre-design',
                                'homepage' => 'oxi-addons-el-template&saetype=pre-design'
                            );
                            $response['Elementor']['templates'] = array(
                                'name' => 'templates',
                                'homepage' => 'oxi-addons-el-template'
                            );
                        } else if ($file[1] == 'elementor_addons') {
                            $response['Elementor']['elements'] = array(
                                'name' => 'elements',
                                'homepage' => 'oxi-el-addons'
                            );
                        } else if ($file[1] == 'beaver_builder_addons') {
                            $response['Beaver Builder']['elements'] = array(
                                'name' => 'elements',
                                'homepage' => 'oxi-addons-fl-builder'
                            );
                        }
                    }
                }
            }
            set_transient(self::TRANSIENT_MENU, $response, 1 * DAY_IN_SECONDS);
        }
        return $response;
    }

}

new Shortcode_Remote();
