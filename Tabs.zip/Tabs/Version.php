<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  Checked By Sabibur Rahman
 */

return array('2.0.0', 'Content Elements', true, 'fas fa-indent');
