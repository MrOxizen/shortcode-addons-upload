<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * Checked by Richard
 */

return array('2.0.0', 'Creative Elements', true, 'fas fa-image');
