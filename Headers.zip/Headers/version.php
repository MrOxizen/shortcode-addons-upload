<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked By - Al-amin
 */


return array('2.0.0', 'Creative Elements', true, 'fas fa-newspaper');
