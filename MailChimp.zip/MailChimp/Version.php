<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  Checked By Md. Al-amin
 */

return array('2.0.0', 'Subscribe form', true, 'fab fa-mailchimp', true);
