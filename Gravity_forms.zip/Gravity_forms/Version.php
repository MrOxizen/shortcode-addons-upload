<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 Edit & Checked by Sabibur Rahman
 */

return array('2.0.0', '3rd Party Widgets', true, 'fas fa-table', true);
