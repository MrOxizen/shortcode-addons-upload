<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * Checked By - Al-alamin
 */

return array('2.0.0', 'Creative Elements', true, 'fas fa-radiation');
