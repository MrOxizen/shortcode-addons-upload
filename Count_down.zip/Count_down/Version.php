<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked BY Sabibur
 */

return array('2.0.0', 'Content Elements', true, 'fas fa-clock');
