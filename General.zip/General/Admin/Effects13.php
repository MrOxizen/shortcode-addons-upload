<?php

namespace OXI_IMAGE_HOVER_UPLOADS\General\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_IMAGE_HOVER_UPLOADS\General\Modules as Modules;

class Effects13 extends Modules {

    public function register_effects() {
        
    }

}
