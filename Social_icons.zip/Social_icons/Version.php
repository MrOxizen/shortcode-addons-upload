<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * Checked by - Al-amin
 */

return array('2.0.0', 'Social Elements', true, 'fas fa-hashtag', true);
