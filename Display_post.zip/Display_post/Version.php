<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * checkde by Richard
 */

return array('2.0.0', 'Dynamic Contents', true, 'fas fa-paste');
