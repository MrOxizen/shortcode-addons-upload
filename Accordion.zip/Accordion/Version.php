<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked by 
 */

return array('2.0.4', 'Content Elements', true, 'fas fa-list', false);
