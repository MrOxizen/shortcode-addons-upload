<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked by 
 */

return array('2.0.3', 'Content Elements', true, 'fas fa-list');
