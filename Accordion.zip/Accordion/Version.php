<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked by 
 */

return array('2.0.1', 'Content Elements', true, 'fas fa-list');
