<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0
 */

return array('2.0.0', 'Dynamic Contents', true, 'far fa-map', true);
