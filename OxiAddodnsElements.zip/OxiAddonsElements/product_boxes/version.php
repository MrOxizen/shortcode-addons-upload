<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.7.1
 */

return array('1.6.0', 'Marketing Elements', true);
