<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.6
 */

return array('1.6.1', 'Content Elements', true);
