<?php

if (!defined('ABSPATH'))
    exit;

function oxi_drop_caps_style_2_shortcode($styledata = FALSE, $listdata = FALSE, $user = 'user') {
    $stylename = $styledata['style_name'];
    $oxiid = $styledata['id'];
    $stylefiles = explode('||#||', $styledata['css']);
    $css = '';

    $styledata = explode('|', $stylefiles[0]);
    echo '<div class="oxi-addons-drop-caps-' . $oxiid . '" id="' . $stylefiles[5] . '" ' . OxiAddonsAnimation($styledata, 35) . '>' . $stylefiles[3] . '</div>';
    $css .= '
            .oxi-addons-drop-caps-' . $oxiid . '{ 
                display: inline-block;
                float: ' . $stylefiles[7] . ';
                display: inline-flex;
                line-height: 1;
                justify-content: center;
                align-items: center;
                color: ' . $styledata[43] . ';
                background: ' . $styledata[51] . ';
                font-size: ' . $styledata[39] . 'px;
                font-family: ' . oxi_addons_font_familly($styledata[45]) . ' !important;
                font-style: ' . $styledata[49] . ' !important;
                font-weight: ' . $styledata[47] . ' !important;
                border-radius: ' . $styledata[53] . '%;
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 3) . ';
                margin: ' . OxiAddonsPaddingMarginSanitize($styledata, 19) . ';
            }
            @media only screen and (min-width : 669px) and (max-width : 993px){
                .oxi-addons-drop-caps-' . $oxiid . '{ 
                   font-size: ' . $styledata[40] . 'px;
                   padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 4) . ';
                   margin: ' . OxiAddonsPaddingMarginSanitize($styledata, 20) . ';
               }  
            }
            @media only screen and (max-width : 668px){
               .oxi-addons-drop-caps-' . $oxiid . '{ 
                   font-size: ' . $styledata[41] . 'px;
                   padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 5) . ';
                   margin: ' . OxiAddonsPaddingMarginSanitize($styledata, 21) . ';
               }  
            }';
    wp_add_inline_script('oxi-addons-animation', 'setTimeout(function () { OxiAddonsEqualHeightWidth(".oxi-addons-drop-caps-' . $oxiid . '");}, 500)');

    wp_add_inline_style('oxi-addons', $css);
}
