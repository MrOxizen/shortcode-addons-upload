<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 */

return array(1.6, 'Creative Elements', true);
