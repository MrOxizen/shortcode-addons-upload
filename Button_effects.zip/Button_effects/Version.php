<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * Checked by Al-almin 
 */

return array('2.0.0', 'Image Effects', true, 'far fa-clone', true);
