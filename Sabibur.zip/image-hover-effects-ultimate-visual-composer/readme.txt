﻿=== Flipbox - Awesomes Flip Boxes Image Overlay ===
Contributors: Biplob018
Donate link: https://www.oxilab.org
Tags: flip box, flip image, flip, wordpress flipbox plugins, flipboxes, flipbox
Requires at least: 4.4
Tested up to: 5.2.3
Stable tag: 2.2
Requires PHP: 5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Flipbox - Awesomes Flip Boxes Image Overlay is the best way to Display your team members staff employees or any type of list.Display you Team page with clean, responsive and professional way.

== Description ==
<strong>Flipbox - Awesomes Flip Boxes Image Overlay</strong>  is a responsive WordPress plugin that lets you add a box to the screen that will flip through the items within the box.

<blockquote>
   <strong>Best Flip Box Plugins for WordPress</strong>
   <br>
</blockquote>

Flipbox - Awesomes Flip Boxes Image Overlay combines the power of “Info Box” & “Call to Action” block altogether. On the front, it would look like a normal Info Box but as visitor hovers on the block, it flips with a cool CSS3 effect and shows a Call to Action section, provoking him to take a call. Add Flip Box in the Any page builder at WordPress, give user more flexibility in the back box, like icon list, image, web link and text info, etc. Flip box offer incredible elements that leads you to create a beautiful site. You can choose from several different flip animations and add two or more items with many different options for cycling through the items.  The Flipbox - Awesomes Flip Boxes Image Overlay’s content are completely customizable. Include images, videos, icons, buttons, maps, etc. make an amazing flip effect on the image. Besides, by beautiful and unrepeatable effects, your image gives a more professional look to your website. It has 28 unique templates with more than 120 effects in, each with Unlimited Backgrounds Colors. Flipbox - Awesomes Flip Boxes Image Overlay Wordpress plugin help to create images with hover effects and scrolling animation. You can create images in a circle and square shapes customly. Fully responsive and Pure Css3 Set animation speed. You can represent your data in very beautiful and descriptive way at once!

<h3>Quick Links</h3>
<ul>
	<li><a href="https://www.oxilab.org/flipbox-image-overlay-demo">Demo (Features)</a></li>	
	<li><a href="">How to Use (Video)</a></li>
	<li><a href="https://www.oxilab.org/docs/flip-boxes-and-image-overlay/getting-started/installing-for-the-first-time/">How to Use (Documentation)</a></li>
	<li><a href="https://wordpress.org/support/plugin/image-hover-effects-ultimate-visual-composer/">Help and Support</a></li>
	<li><a href="https://www.oxilab.org/downloads/flipbox-image-overlay/">Upgrade to Pro</a></li>
</ul>

Flipbox - Awesomes Flip Boxes Image Overlay are one of the best in responsive Flip Box image plugins which allow you to decorate your product or information page beautifully of the website. It is very powerful and lightweight flip box and image overlay plugin. You can present your product info on your website at a quality and professional way by using this plugin.  Flipbox - Awesomes Flip Boxes Image Overlay is the best way to promote your product by creating amazing sliders with beautiful transition effects. The plugin has the effective tool for adding responsive slider to your website. The WordPress flip box plugin can be added both as a widget and plugin, as well as be included in the theme for displaying the images within the theme using PHP function.  You can choose from a different box types and use the provided shortcode or a template or Visual Composer ID includes to easily embedding Flip box in your Website.

<strong>Drag & Drop with unlimited style</strong>

Flipbox - Awesomes Flip Boxes Image Overlay permit you to add Image Overlay and Flip Box in any Page Builder. Give user the flexibility to display card related content, card content support text, image, icon and so on. 

This plugin is very simple to use, but have a bunch of features that exists on a first class quality plugin. We develop our plugin in concern of both beginner and expert WordPress plugin users. So you can find both user-friendly interface and quality features of flip box image with unlimited effects here with Flipbox - Awesomes Flip Boxes Image Overlay.  Flipbox - Awesomes Flip Boxes Image Overlay is very simple to create an image flip and slider on your WordPress website. You can add images (PNG, JPG and GIF format), as well as, add posts, pages in template files. Flip Box allows adding titles, descriptions and links to unlimited photos on both front and back side of an image. The plugin has a Shortcode built in. Every new created item has his own ID number. It makes it easier for plugin installation in any site. You can also use visual composer page builder in Flip Box plugin. This will add extra convenience to the advance users.

<strong>Advantages of the Plugin </strong>

Flipbox - Awesomes Flip Boxes Image Overlay are the best solution for those who want to demonstrate images in a superb way on their site! You can reach this result due to the Flip box plugin. When creating the flip box or image overlay items with image hover effect, we took into consideration not only the design but the functionality as well. So let’s enjoy the Flip Box which has been made by following the latest design tendency. Our Flipbox - Awesomes Flip Boxes Image Overlay plugin allow you to modify all settings, such as colors, fonts and sizes, which are corresponding, to the standards of the flip box. This plugin has that all features in one that you can expect from different free flip box image plugin. You can create an unlimited flip box and images to have lots of effects on it.

<strong>Awesome Functionality</strong>- Flip boxes with animation effects are simply awesome. They are great for grabbing the users attention and adding some interaction with your content. Our flip boxes and image overlay plugin has fully customizable content on the front and back side. They are fully integrated with the Font Awesome icon set and icon options like spin, rotate or flip. You can put a title on the front and back side, add buttons with link in it to your content and the box height will extend based on the amount of content you use. Customize the border size, border radius and have full control over the front and backside colors and you can animate them with awesome CSS3.

<strong>Column and Row Sizes</strong>- Flip boxes have their own column and row option to set which allows the content box to fill the column width from 1-4 columns. They can also be used inside of our regular column shortcode to control their placement on the page. You can select the amount of the item that will fill a single row. This option will allow you to have full control of flip boxe placement in your webpage!

<strong>Built in Visual Composer</strong>- Flipbox - Awesomes Flip Boxes Image Overlay has every feature what you can expect from a free flip box or image hover plugin. It has a complete, easy-to-use flip box and image overlay effect builder with different layers with visual composer built in. Oxilab Developers make this plugin easier to Visual Composer Users by adding an awesome panel for Visual Composer. Just add Your Element in Visual Composer from “Flipbox - Awesomes Flip Boxes Image Overlay” Content bar menu. Besides Visual Composer, others page builder is also working With Short Codes.

<strong>Pagination and Attractive Interface</strong>- Flipbox - Awesomes Flip Boxes Image Overlay is a responsive flip box creator plugin with slider and animation. Awesome pagination icon and button is available with this plugin. You can simply choose your preferred one at the awesome user interface. The interface is so much cleaner that anyone will able to work here without having any trouble at using. You can display your product on the website very informative and attractive way. You can also display stuff profile or testimonial with this plugin.  Here you can find different sets of parameters for each category. Styles and Colors section of Flipbox - Awesomes Flip Boxes Image Overlay is very much able to customize the color scheme and overall appearance of the contacts. It is very simple and easy. Anybody who is not even a developer can make this change to their webpage with Flipbox - Awesomes Flip Boxes Image Overlay Wordpress plugin.

<strong>Unique Design</strong> - Flipbox - Awesomes Flip Boxes Image Overlay is a unique plugin for Wordpress that is very much customizable and responsive. Our super-fast and attractive user interface can impress any WP developer in no time. Flipbox - Awesomes Flip Boxes Image Overlay have very beautiful and orderly decorated admin panel. It is very user-friendly and simple to work with.  

<strong>Fully live design and custom interface</strong>- Never again work on the backend and guess what the front-end will look like. With Flipbox - Awesomes Flip Boxes Image Overlay, every time you edit the page and simultaneously see exactly how it looks like at the same editing page. Flipbox - Awesomes Flip Boxes Image Overlay features live editing, with no need to press update, or go to preview mode. This plugin developed with a strong and customizable interface and you can use the provided template to easily embed with Flipbox - Awesomes Flip Boxes Image Overlay in your Website. With this plugin you can create unlimited Flip boxes and Image sliders using unlimited shortcode. So you can display your created Flip box and slider on multiple page and post by using shortcode.

<strong>Mobile Editing and Canvas</strong>- Flip box’s responsive framework allows your content looks great on all screen sizes. Flipbox - Awesomes Flip Boxes Image Overlay Wordpress plugin comes with an exclusive tool set that let you create truly a responsive website in a whole new and visual way. From different font size per device, this is the most powerful solution for creating perfect mobile pages. You can develop your webpage with our plugin simply using your mobile device. Flipbox - Awesomes Flip Boxes Image Overlay are 100% responsive and compatible with mobile, tablets, desktop computers and all modern web browsers which include iPhones, iPad, Android, Chrome, Safari, Firefox, Opera, Internet Explorer 7/8/9/10/11 and also Microsoft Edge.

<strong>Built for Developers</strong>- Flipbox - Awesomes Flip Boxes Image Overlay was designed to be the most developer-friendly Flip box building plugin available for WordPress. It was also built on top of a solid extension framework, which means different functionality is separated out into different areas in the codebase. It also means the core plugin is lightweight, but still allowing for the most flexibility. This plugin is built in visual composer. With the visual composer page builder on it developers can find the easy way to work with the popular builder they used to. Visual composer is one of the popular and effective page builders within others. So the visual composer's facility will bring our plugin more user-friendly and convenient to the developers.  

<strong>Custom CSS</strong>- Wordpress professional developers can get advanced tools and freedom of creativity with our plugin. They can use their custom styling within Flipbox - Awesomes Flip Boxes Image Overlay Wordpress plugin with visual composer. Advanced developers can add their custom css into the plugin very easily. There’s a section we’ve left for this task. Here like other plugins of oxilab’s also with Flipbox - Awesomes Flip Boxes Image Overlay, the expert developers can find their comfort as we support custom css with our plugin. Developers can develop their custom css and add them to the plugin so that they can get what they exactly want in Flipbox - Awesomes Flip Boxes Image Overlay plugin. This is very much convenient for a developer to have an option to customize the css codes.

<blockquote>

IMPORTANT: If you think you found a bug in Flipbox - Awesomes Flip Boxes Image Overlay  or have any problem or question concerning Flipbox - Awesomes Flip Boxes Image Overlay Builder plugin, do not hesitate to contact us at www.oxilab.org.

</blockquote>

<strong>Here you can see some of the features of our plugin</strong>

<ul>
	<li>Highly custom and incredibly flexible Flip Boxes</li>	
	<li>Responsive layout (28+)</li>
	<li>1-click automatic updates</li>
	<li>Optional title and content.</li>
	<li>Optional display text with icon or image.</li>
        <li>Different sets of parameters for each</li>
	<li>Stunning buttons with over 60 animation effects</li>
	<li>Easily Customizable flip boxes</li>
        <li>Built by the Bootstrap web builder</li>
	<li>Valid on pure HTML5 and CSS3 </li>
	<li>Ultra Responsive and 100% Mobile-friendly</li>
        <li>Sleek, clean and modern design</li>
	<li>Animated sliding Panel </li>
        <li>Looks great on desktop & mobile</li>
</ul>

While using Flipbox - Awesomes Flip Boxes Image Overlay please make sure that thumbnail images are linked directly to their larger counterpart, not to a dynamic WordPress page that includes the larger image. That means when you add an image in your new flip settings, you need to select File URL at the Link option instead of Page URL. That is for the direct image file, not any other file that is not consists of images. You’ll have to manually edit your old posts if you have always inserted images with Page URL before, Flip Box or any other plugin like that cannot import images from the outer link for you.

You’ll need to make sure that you have all the needed media and their Auto-detect options activated on your Settings > Media library page. If you are using images in other formats like JPG, GIF or PNG, you need to add the extensions with the image link to the Auto-detect the field for Images. Please note that the image file names must actaully end with that image file extension. This means that if you have an image file that (for example) has no extension (does not end with .jpg or any other) even if is in JPEG compressed format, the Flip Box and Image Overlay will not be able to detect is as an image. And as a result you’ll get no image at all on your flip box. You will need to manually give those.

<strong>Flip Boxes Key Features<strong>

Flipbox - Awesomes Flip Boxes Image Overlay aims to make your website more attractive and good-looking than ever. The Flip Box Plugin has many functions. So you can create flipped image not only with title and social description, but also Customize with CSS form like font-size, color, background color, border-radius, box-shadow, padding, margin and more. Lot of slider effects we’ve left with the plugin. Let’s see, which features the plugin offers-

<strong>Awesome Interface</strong>- Flipbox - Awesomes Flip Boxes Image Overlay designed with a simple, easy to use interface – perfect for individual users, developers & clients!

<strong>Color Control</strong>- Control all the colors of each element you can see with this plugin! Flip boxes and Image Overlay WP plugin allow you to control the color of the backgrounds, title text, body text, icons, icon circles and borders. You can set colors individually in the shortcode, or globally in our theme options panel. Take full control of your colors and make the flip box an awesome way to present your item with ease.

<strong>One-Click Presets</strong>- To provide the easiest way to customize the display of your content without editing any code. You can use the default Responsive styles or one of the included one-click presets as a starting point for customization. It also enables you to easily add social button and link to your content flip box image.

<strong>Awesome Admin Panel</strong>- the Admin panel of the plugin is way more better from the others similar plugin. Users will find more comfort and interest while working with the plugin.

<strong>Instant Customizing Option</strong>- With the instant customizing facility users can edit/delete/update the flip box image Content at any time they want.

<strong>Demo</strong>- We decorated the demo page with the template of team showcase. You can select a template from template Select page instantly and very faster before start to adding the information. We developed very Awesome, modern and unique team showcase templates on our demo page.

<strong>Use just an image</strong>- Wanna use an image instead of using an icon? You can choose to use an image that will show up in the same area as the icon with this plugin. The settings allow you to specify the exact image size so it displays perfectly in the box. Using an image instead of an icon opens up a whole new look for the flip boxes and gives additional creative uses.

<strong>Animation</strong>- There are many animation effects for the flip boxes. Select your preferable animation effect.

Title / Description-This option hides/shows the title and description.

Title Color- This color selection is for the header, which appears on slides.

Description Color- This option is for selecting colors for description, which appears on slides.

Overlay Color- This choice is to overlay that appear as background for titles a description on the image.

Add images via external URL- You can also include external URL images. By using this feature, you can add a completely different image patterns to your flip box image.

Automatic Image Cropping- Flipbox - Awesomes Flip Boxes Image Overlay plugin can automatically resize your images to a size you specify, so you don’t have to worry about doing it manually yourself. So you don’t need to worry if your images are too big or too small, they will all come out the same size in the slider.

Pixels or percentage- we allow Pixels or percentage to customize the width and height of the flip box image.

<strong>Cross Browser</strong>- Tested in major desktop, tablet, and mobile browsers and fully featured in Firefox, Chrome, Safari, Opera, and Internet Explorer 10+. With support for Internet Explorer 8 and 9 via a fallback theme; a traditional side-to-side.

Images – Allows you to specify different image sources for different screen sizes. For example, mobile devices will load smaller images.

<strong>Touch Support</strong>- Touch swiping and tapping supported to allow for navigation between steps.
 
<strong>Highly responsive awesome Flip Box!<strong>

Flipbox - Awesomes Flip Boxes Image Overlay themes come with their own settings and preset skins that can be customized without any HTML or CSS knowledge at all. You can define multiple instances of the image flip box, and then you can arrange the items with the help of widgets and shortcodes. Professional and responsive Flip Box plugin has an amazing transition effects, sequence of the other images: Fade, Cross Fade, Slide, Slideshow, Slice, Blinds, 3D, 3D Horizontal, Horizontal, Vertical, Blocks and Shuffle. Flipbox - Awesomes Flip Boxes Image Overlay give to image a unique look and beautiful design. Animation options allow adding different transition effects for the responsive flip box. The flip box will give a unique look to your product profile or item to display, with its descriptions and titles which also has their own effects. Flipbox - Awesomes Flip Boxes Image Overlay can help to improve your website in a number of ways, such as strong interactivity, add more style, save space and make content more attractive, linking to other pages and much more! All widgets in this plugin are fully Responsive and Customizable also they are pretty SEO friendly.

<strong>Lots of widgets</strong>

We packed lots of the most useful widgets into our Flipbox - Awesomes Flip Boxes Image Overlay Wordpress plugin. True, that’s way more than we had to offer, but we wanted to spare no widget from you, so you can reach the top of your design capabilities. Here is a list what we offer:

Title And Description- You can add Title and Description for all the images within the flip box it will beautifully overlay on the flip boxes and image overlay with the slightly transparent background or even your own selected background. You can customize the background opacity as well. Also, you can add some link on the background image. You can put a title on the front and backside.

Icon Heaven- Font Awesome Icons are tightly integrating into the flip boxes along with multiple options; icon color, circle, color and border, circle show or hide, icon flip, rotate, spin and animate.

Options for Content Customizing- You can use Google fonts, change the size, color, font, background. Creating all this you will have the original Slideshow with pretty content. You also can add buttons to your content and the box height will extend based on the amount of content you use.

Adds Title Style- You can do more styling with the Flipbox - Awesomes Flip Boxes Image Overlay on the title of your each image.

Border Control- Flip boxes and image overlay allow you to use borders and set the border width, color and radius. You can even set the border properties individually per box to make one box stand out from the others with featured content. Take full control of your borders with this plugin.

Create Description Style- Description Style section suggests choosing different effects and colors for the flip box images.

Social Sharing – Navigate to your flip box and click the Social Sharing option in the slider menu in order to add unlimited social sharing icons on the item. You can pick a couple from available Facebook, Twitter, Google+, Pinterest, LinkedIn, blogger, Instagram, Tumblr and much more. 

Beautiful Slideshow and Flip Effects- Flipbox - Awesomes Flip Boxes Image Overlay makes displaying your gallery of images a beautiful experience, by using amazing slideshow and flipping effects.

Width and height- Flip Box width and height is for making the image size within the box more accurate. What you need is just give the right size for the images of the Flipbox - Awesomes Flip Boxes Image Overlay Plugin.

Custom URL- When adding an image in flip box, you can make it so it links to a specific page. You can set URL for each image that works on button/icon click.

Mobile-Friendly plugin- Flipbox - Awesomes Flip Boxes Image Overlay are fully responsive, which means you can open your image slider on various devices: Smartphones, Tablets, desktop.  

Custom Element Button- Add a button with the link to the images of the flip box and add suitable styling to the button as well.

Custom Element Image- Add images on the flip box and do suitable styling and customization with the images. You are able to add images from the Media Library.

Advanced Flip Box Shortcode – Flipbox - Awesomes Flip Boxes Image Overlay has 2 shortcode types: One is prepared to be included on your WordPress post or page and the other is for inserting the Flipbox - Awesomes Flip Boxes Image Overlay within your theme. You can customize the embedding of the flip box on your website.

<strong>Highly Customizable Flip Box<strong>

Flipbox - Awesomes Flip Boxes Image Overlay WP plugin is very much customizable and professional. You can customize the page with a lot of features. Our plugin built with very user-friendly atmosphere. Developers can find more option to customize their flip box gallery. We’ve left a bunch of option to work with. Here at this point we’re going to discuss about the some customizing option that you’ll find in the plugin editor page. Let’s talk about them… 

Flip Box Creation- On the plugin submenu you’ll find the first modification option named “Create New”. With this option you can create a Flip Box image and customize them with text, button, icon, link fonts, effects, color, animation, navigation, slider and much more. This option is the primary and also the main option of adding flip box image gallery. Within this option you’ll find the place where you can upload the image for flip box. After finishing upload you can find a different customizing section. On the first there’s the general setting under 4 sections of customizing option. You can customize the image, links, animation, box shadow here. We’ll discuss the rest of them later in this article.

Flip Settings- When you click on the “Add New Flip” option, you’ll find a flip image modification form. Here you can add a front and backend image for the flip. You can select the flip type and effect from the option. In this form you’ll need to fill up the front image and backend image info. You can fill the front boxes with a title, description and font-awesome icon which will allow you to get a nice icon. On the backend image you can fill the boxes with title, description and button text. Here you can put a link for the button to create a linked image. For both front and backend image we’ve left full color customizing control to your hand. You can customize the background color, border color, icon color, icon background color, heading color and text color. Also for the backend image you can customize button color, button background color, button hover and button hover background color. The color modification is all for you!

General customizing option- Here you can customize the general effects of the flip box image. You can customize how many image you want per row at once. Then you can customize height, width, border radius, margin, link opening, animation and box shadow effects. Lots of customizing options are left to your hand so that you can decorate your flip box at your own style and effect.

Separated customizing option- With Flip boxes and Image Overlay plugin you’ll find the unique separated customizing option for both front and backend image. You can customize these two sections separately. That means you have the access of full modification in deepest version. You can modify the general effects of front and back image. The heading and info text will be able to edited here in front and backend option. You can customize the icon settings of front image and button text settings of back image here. The unique modification option will give the plugin users a new experience of using flip box plugin.

Slider Settings- Flipbox - Awesomes Flip Boxes Image Overlay also consists of sliding effect with image hovering in it. You can turn on sliding to get slide effect on your flip box image. You can also customize the navigation buttons or arrow settings, decorate them with custom color, size, style, positioning and hovering. The pagination settings is for customizing the pagination effect here. You can decorate pagination effect with very clear and specific option. 

== Installation ==

<p>Installation of <strong>Flipbox - Awesomes Flip Boxes Image Overlay</strong> is very simple.</p> 
<blockquote>


<strong>Option 1</strong>

<li> Download the plugin image-hover-effects-ultimate-visual-composer.zip from Wordpress Plugin Directory.</li>
<li> Unzip file into image-hover-effects-ultimate-visual-composer folder.</li>
<li> Drop the image-hover-effects-ultimate-visual-composer plugin folder into your wp-content/plugins folder.</li>
<li> Refresh your Wordpress Administration panels, click on Plugins from the menu.</li>
<li> You will see Flipbox - Awesomes Flip Boxes Image Overlay plugin under Inactive plug-in tab.</li>
<li> To turn on Flipbox - Awesomes Flip Boxes Image Overlay , click  on activate.</li>

</blockquote>

<blockquote>


<strong>Option 2</strong>

<li> Download the plugin image-hover-effects-ultimate-visual-composer.zip from Wordpress Plugin Directory.</li>
<li> click on add new  under plugins menu.</li>
<li> Upload the available Flipbox - Awesomes Flip Boxes Image Overlay Plugin file and click install now</li>
<li> After installed click on active to tern on.</li>

</blockquote>

== Frequently Asked Questions ==

WordPress Flipbox - Awesomes Flip Boxes Image Overlay Plugin

= Whether, is the Flipbox - Awesomes Flip Boxes Image Overlay support basic HTML Elements? =

Yes. Basic Html has a support possibility.Such as you can add </br>,  <strong> .

= Is the Flipbox - Awesomes Flip Boxes Image Overlay Responsive? =

Yes, reacts and displays resizing images, videos, titles and descriptions for mobile devices and tablets.

= I bought Flipbox - Awesomes Flip Boxes Image Overlay Plugin, I have not received it yet. Please suggest, how can I activate it or get the Pro version? =

If You acquired the Flipbox - Awesomes Flip Boxes Image Overlay and have not received it, please just contact with our Support Team. Send a letter with purchase Flipbox - Awesomes Flip Boxes Image Overlay Order Number.

= I use free version of Flipbox - Awesomes Flip Boxes Image Overlay and placing Pro version arise a problem, what to do? =

- Please delete the free version until installing the Pro version.

- Download Flipbox - Awesomes Flip Boxes Image Overlay Pro version. If You still see the old version press Ctrl+F5 for refresh the page.

- If you can not do that, please contact with us, we will solve this little problem.

= How to enable the Flipbox - Awesomes Flip Boxes Image Overlay to in a post or page? =

[oxi_oxilab_flip_box_show id="1"]
= How to enable the Flipbox - Awesomes Flip Boxes Image Overlay to in a page or Template? =

&lt;?php echo do_shortcode(&#039;[oxi_oxilab_flip_box_show  id=&quot;1&quot;]&#039;); ?&gt;

== Screenshots ==

1. Flipbox - Awesomes Flip Boxes Image Overlay Template Demo
2. Admin Panel.
3. Live Preview. 
3. Popup Data Input form.


== Changelog ==
= 2.2 = 
*Fixed Single Quotation Mark

= 2.1 = 
*Fixed Bugs with Page Builders

= 2.0 = 
*Update Admin panel

= 1.9 = 
*Fixed with Gutenberg

= 1.8 =
*Fixed Export Bugs

= 1.7 =
*Fixed Some Bugs

= 1.6 =
*Fixed Some Bugs

= 1.5 =
*Added Font Awesome Version
*Fixed Bugs

= 1.3 =
*Mobile Issue Solved

= 1.3 =
*New Layouts
*More theme capabilities 

= 1.0 =
* Initial Release
* Added 23+ responsive layout

== Upgrade Notice ==
= 2.2 = 
Fixed Single Quotation Mark

= 2.1 = 
Fixed Bugs with Page Builders

= 2.0 = 
Update Admin panel

= 1.9 = 
Fixed with Gutenberg

= 1.8 =
Fixed Export Bugs

= 1.7 =
Fixed Some Bugs

= 1.6 =
Fixed Some Bugs

= 1.5 =
Added Font Awesome Version
Fixed Bugs

= 1.4 =
Mobile Issue Solved
= 1.3 =
Customize Flipbox

= 1.1 =
Add user capabilities
More theme capabilities 