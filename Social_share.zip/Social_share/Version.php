<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  Edit & Checked By Sabibur Rahman
 */

return array('2.0.0', 'Social Elements', true, 'fas fa-share-alt-square', true);
