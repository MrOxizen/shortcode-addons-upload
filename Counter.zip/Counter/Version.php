<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
  Edit & Checked BY Sabibur
 */

return array('2.0.0', 'Creative Elements', true, 'fas fa-clock');
