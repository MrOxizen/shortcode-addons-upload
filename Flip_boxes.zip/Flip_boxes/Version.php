<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked by Richard
 */

return array('2.0.0', 'Image Effects', true, 'fab fa-flipboard');
