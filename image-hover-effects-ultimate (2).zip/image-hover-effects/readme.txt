=== Image Hover Effects Ultimate - Captions Hover with Visual Composer Extension ===
Contributors: biplob018
Donate link: https://www.oxilab.org
Tags: responsive image effects, awesome css3 effects, awesome image effects,  css3 effects, effects, top image effects for wordpress,  hover effect. 
Requires at least: 3.0.1
Stable tag: 9.2
Tested up to: 5.2.3
Requires PHP: 5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Image Hover Effects Ultimate - Captions Hover with Visual Composer is an impressive, lightweight, responsive Image hover effects. Use 150+ modern and elegant CSS hover effects and animations.


== Description ==

> **Best Image Hover Effects or Captions Hover Plugin for WordPress**
   
**Image Hover Effects Ultimate – Captions Hover with Visual Composer** is an impressive, lightweight, responsive Image hover effects. Use modern and elegant CSS hover effects and animations. Best Used for portfolio/ gallery/image showcase items in WordPress site using shortcodes and custom post. Consider the comfort of developers, we lunch an advanced pure CSS3 based hover effect plugin named Image Hover Effects Ultimate – Caption Hover with Visual Composer. It is fully responsive. Bring your images to live with some beautiful animation and transition with this awesome plugin.

>  Your suggestions will make this plugin even better, so  [let us know ](https://wordpress.org/support/plugin/image-hover-effects-ultimate#new-post "let us know") if you need any assistance or help.
  
Hover effect on the image is an important part of creating an attractive and professional looking webpage. With Image Hover Effects, you can reach your website an apex level of beautifulness. In the past, we had to rely on Javascript for getting those special images hover effect on our webpage. And that was complicated enough as firstly we had to been through complex Javascript coding which could be the scariest thing for some people. And secondly we had to hire an expensive developer for accomplishing this task. It was the biggest problem for non-programming person who wanted to develop their own site for the amateur usage or something like that, such as a personal blog or something that is not much professional, but essential. In those days they had to learn coding even though they didn’t want to, or they had to solve the coding stuff by hiring a programmer. For those reasons they had to face much complexities if they want to add a special hover effect, or add caption hover to their webpages. But now-a-days plugin like Image Hover Effect brings us the special convenience to add captions hover/image showcase items/image hover in WordPress site using shortcodes and custom post. 


=Quick Links=

+ [Demo (Features) ](https://www.oxilab.org/image-hover-effects-ultimate-demo "Demo (Features)")
+ [Demo 1(General Hover Effects) ](https://www.oxilab.org/image-hover-effects-ultimate-demo-general "Demo 1(General Hover Effects)")
+ [Demo 2 (Square Hover Effects) ](https://www.oxilab.org/image-hover-effects-ultimate-demo-square "Demo 2 (Square Hover Effects)")
+ [Demo 3 (Button Effects) ](https://www.oxilab.org/image-hover-effects-ultimate-demo-button "Demo 3 (Button Effects)")
+ [How to Use (Video) ](https://youtu.be/fUZ1SC0UAtY "How to Use (Video)")
+ [How to Use (Documentation) ](https://wordpress.org/plugins/image-hover-effects-ultimate/#installation "How to Use (Documentation)")
+ [Help and Support ](https://wordpress.org/support/plugin/image-hover-effects-ultimate#new-post "Help and Support")


Consider the comfort of developers we’ve lunched an advanced pure CSS3 based Image hover effect plugin named Image Hover Effect Ultimate. A non-coding person can easily develop his/her own site by using our plugin. We designer our image hover plugin very handy for all users. Everybody can add a beautiful image with amazing hover style to their web page by using our plugin. Image hover effect ultimate Wordpress plugin is fully responsive hover effect plugin with Visual Composer built into it. With this plugin a developer can easily add 60+ amazing image hover effects/caption hover (with pro version) without any scripting at all. Bring your images to live with some beautiful animation and transition hover effects with this awesome plugin. Image hover effect on your website it’s really attractive and very important part of your page. If you are looking for fast, easy caption hovers effect with simple and very beautiful, highly customizable design here is it. Caption hover where even newbie in WordPress will be able to create your first image effect with slide show and a carousel in a few minutes. And at the same time WordPress professional developers can get advanced tools and freedom of creativity. Just download this Image Hover Effect Ultimate plugin and you’ll not look for any other Hover Effect anymore!


=Advantages of the Plugin=

Image Hover Effects Ultimate – Captions Hover with Visual Composer is an impressive, lightweight, responsive hover effects plugin. We used modern and elegant CSS3 style to design the hover effects style and animations. Best use of this plugin is for image hover/caption hover/portfolio/gallery/image showcase items. In WordPress site using Shortcode and custom post make this image hover plugin more user-friendly and touch enable the feature. Image Hover Effects Ultimate a standard and intuitive WordPress Hover Effect plugin to create image effects, add carousel and a slider which have never been possible before with any free image hover plugins.

**Built in Visual Composer Extention**

Image Hover Effects Ultimate– Captions Hover with Visual Composer has every feature what you can expect from a free hover and slider plugin. It has a complete, easy-to-use hover effects editor with different layers with **Visual Composer** built in. Oxilab Developers make this plugin easier to **Visual Composer** Users by adding an awesome panel for **Visual Composer**. Just add Your Element in Visual Composer from **Image Hover Ultimate** Content bar menu. Besides Visual Composer, others page builder is also working With Short Codes.

=Touch Enable Feature=

Image Hover Effect Ultimate can be enjoyed in any environment. Be it on a mobile, tablet or desktop no matter which device or screen size it is, our plugin will be responsive to that. We support Touch navigation on mobile browsers. Each design of Image Hover Effects Ultimateworks on any Touch Screen device very smoothly. You will find your image hover effects be very responsive on iPhone, Tabs, Android or and Smart Phone. So don’t be hesitated to publish your Hover Effects on each device you want.

=SEO-friendly and best eCommerce solution=

Using Image Hover Effect Ultimate WordPress Plugin a WordPress developer can easily create SEO-friendly image hover effect to individual image so that their customers simply reach to exactly the right product/item details right away. You can easily add links to your image hover to popular social media, such as Facebook, Twitter, Tumblr, Instagram, VK, Google Plus, the interest so on, so that your customers can help you to spread the word about your product! It is pretty cool, isn’t it? 

We designed Image Hover Effect Ultimate plugin, including some exceptional features. Our plugin is much more effective when you use this for any eCommerce website. With Image Hover Effect Wordpress plugin, you can easily add an image hover item to each product page, so that your customers can see the full description about the products they’re browsing just by hovering over the image. It’s the most comprehensive solution for every eCommerce site!

=Clone Image Settings=

If you have multiple of images on the website this feature is really useful for you! Clone settings of one specific image effect to apply it to another image. So you can copy the styles of the source image to as many images as you need just by one click. It is a great convenience for them who need to add more images at once. They will no longer need to customize the image one by one. It is very time consuming and boring also. This clone image option you will find on the image hover list. We will discuss it in details later on.

=Live Preview=

With our plugin we always develop Live Preview interface, so that users will find more comfortable and interest editing with our plugin. Image Hover Effects Ultimate– Captions Hover with Visual Composer also designed with a live preview interface. You can see your customization at the live page you editing the image. It will bring a great advantage for the editors.

=Built for Developers=

Image Hover Effects Ultimate– Captions Hover with Visual Composer was designed to be the most developer-friendly image hover plugin available for WordPress. It was also built on top of a solid extension framework, which means different functionality is separated out into different areas in the codebase. It also means the core plugin is lightweight, but still allowing for the most flexibility. This plugin is built in visual composer. With the visual composer page builder on it developers can find the easy way to work with the popular builder they used to. Visual composer is one of the popular and effective page builder within others. So visual composer's facility will bring our plugin more user-friendly and convenient to the developers.

=Custom CSS=

WordPress professional developers can get advanced tools and freedom of creativity with our plugin. They can use their custom styling within Image Hover Effects Ultimate– Captions Hover with Visual Composer WordPress plugin. Advanced developers can add their custom CSS in the plugin very easily. There’s a section we’ve left for this task.


=Image Hover Key Features=

=Basic Features=
> + **Clone Hover Effects** With this plugin you can use the Clone option to copy the styles of the source image to as many images as you need just by one click.
> + **Auto-resizing for thumbnails and images** Image Hover media manager allows you to make additional customization of the images, like: rotation, flip, crop, manual resize.
> + **Implemented to avoid AJAX libs conflicts** All images hover effects’ code implemented in native WordPress style as result, our image hover effects don’t have any conflicts and work really stable.
> + **Font settings** Image Hover Effects Ultimate– Captions Hover with Visual Composer have built in advanced text style editor options. With this convenient you have full control to customize title, caption, and description of every image.
> + **Implemented in native WordPress style using native classes** Image Hover Effects Ultimate fully a secure plugin. It is fully native for WordPress implemented without any hacks and tricks.
> + **Classic hover layout** layout of the image hover could have classic style or grid layout, every hover effect on the page could have own styles and settings. You have full control to customize them on your own.
> + **Works perfectly in IE, Firefox, Safari, Opera, Chrome** Image Hover Effects Ultimate– Captions Hover with Visual Composer works properly with all latest versions of the popular browsers.
> + **Overlay effects** all hover effects of the Image Hover Effects Ultimate– Captions Hover with Visual Composer thumbnails are highly customizable and have a full set of options.
> + **Backend text settings, preview** All hover effects images, titles, captions, descriptions are highly customizable and also, we have a live preview of the changes in image hover backend.
> + **Optional mobile tech support** Our plugin support mobile devices and you can customize responsive gallery layout settings for different screen sizes.
> + **Ability to insert images into the WordPress post, page, widget** Every image hovers the item could be inserted in to post, page or widget with built in short code tag or using the wizard button – short code generator in post or page editor
> + **Image Alignment** Alignment of the image in post or page depend on your needs. You don’t need to use HTML tags or some CSS tricks to accomplish this task. This function in the plugin going to help you to align your images hovers the way you need. Possible to select one from implementing alignment modes: left, right, center of images hovers item alignment inside a post or page content.
> + **Image Padding** New padding options. Define custom values in pixels for padding image block in a post or page content.  It is possible to define padding from left, right, top and bottom side individually.
> + **Plugin Compatibility Settings** In Image hover effect ultimate settings you can customize the general image hover plugin settings to avoid conflicts with other plugins or WordPress theme.
> + **Image Hover Cache** Incredible new super cache option makes your page with image hover effect load ten times faster than ever. This function use absolutely new model of the images load. When you enable caching for the more image item, it’s going to be much faster and effective to use our plugin. Your visitors will be really surprised by the speed of the page load.

=Pro Only Features=
> + Customizable 150+ hover effects – Image hover effects Ultimate is working in cooperation with hover effect interface configuration options. You can easily change styles and colors of the hover animation elements. With those default styles you’ll find multiple effects on each.
> + Fully responsive and Mobile enables – Image hover effects ultimate is very much responsive. This plugin implemented with advanced settings for different device's screen size.
> + Build in color selector – With this plugin you can easily customize the color of any image, text, background image, or effect style.
> + Build in borders and shadow settings – Image hover borders and shadows have advanced options for configuration design and style of this image hover effect interface elements.
> + Image Hover background color – In image hover settings you can change color of the background with comfortable color picker.
> + Image Hover background transparency – In image hover settings you can change the transparency of the background with comfortable color picker. Or you can set the decimal value on your own. 
> + Customizable hover icons – all icons of the gallery buttons fully customizable and every icon could be easily changed with build in icons wizard
> + Image Hover font color – In image hover settings you can change color of the font with comfortable color picker.
> + Amazing responsive style effects
> + Unlimited hover items
> + Custom font size both heading & descriptions. 
> + 650+ Google fonts. 
> + Show / Hide text underline
> + Unlimited heading font color
> + Unlimited description font color
> + Texts adjustments. 
> + External link for each hover item.
> + Show/Hide border. 
> + Open link in new tab. 
> + Custom css generating. 
> + Very easy video tutorial. 
> + 24/7 Customer Support. 
> + Support within 12 hours. 

=Responsive & Beautiful=

**Image Hover Effects Ultimate– Captions Hover with Visual Composer** is a very responsive image hover plugin what is really important for the website page rank, especially for the e-commerce. Image Hover Effects Ultimate– Captions Hover with Visual Composer work on mobile devices as stable part of your website interface. This plugin’s also fully responsive and mobile devices friendly. Image Hover Effects Ultimatemakes displaying your image hover a beautiful experience, by using amazing style effects and animation ranging from slicing and sliding to fading and folding. There simply is no better way to showcase your amazing work than to make the presentation of it looks just as beautiful as it were never before! With our plugin you can use Google fonts, change the size of the font, color, opacity, background, aligning and much more. Creating all this you will have the original Image Hover with pretty content on it.

>  Your suggestions will make this plugin even better, so  [let us know ](https://wordpress.org/support/plugin/image-hover-effects-ultimate#new-post "let us know") if you need any assistance or help.

This Image Hover Effect plugin comes with a few demo effects on its demo page, which are representing the main types of hover effect style supported by the plugin, whereas you can always enhance the plugin functionality combining hover effect types. There you’ll find 150+ different effects with minimum 4 style layouts containing each. This imposing WordPress Plugin is powered by genuine CSS3. It is very user-friendly and very attractive plugin for any WordPress website. We used short codes and custom post on Image hover effect ultimate so that a developer can set the image title very fashionable and attractive. This plugin will help you to make your website more furnished and standard looking. Image Hover Effects Ultimateincluded with Image Zoom, Image Flips, Border Hover, Fading and Sliding Effects, Content Overlays and much more. You can create some simple, yet stylish hover effects for image captions. The idea of this hover effect plugin is to have a grid of figures and apply a hover effect to the items which will reveal a caption with the title, author and a link button. As we left a lot of options and created many features on Image hover effect ultimate plugin, users can easily manipulate the hover style as they need to.

**Awesome Hover Effects**

Image Hover Effects Ultimate– Captions Hover with Visual Composer comes with 3 different effect style sections. You can insert your image on your website at very simple and flexible way by using our interactive and modern image hover effects ultimate plugins. It’s Fast to Configure and easy to use and has a bunch of setting and options to setup as per as you need. On our plugin main interface, it’s representing the three types of Effects supported by the plugin, where you can always extend the plugin functionality combining Effect type. The mentioned three types are General Effects, Square Effects and Button Effects. Let’s discuss each of these Image Effects types separately.

**General Effects** Here with this effects type, you can add 29 different effects. Those are awesome hover effect with having a lot of customization options. With each effect, it’s containing up to 4 style layouts. You can customize them later, after adding image for getting the effects. Firstly, you can add title, description, icon, button, image animation, content animation with the effects on this “General Effects” type. Secondly, you can customize the type of image showing whether it’ll appear as Square or Circle as with these effects type we left the customization option with a bunch of modifying options. By using radius, you can control the image type and size. With the custom border radius elements, Pro version’s users of Image hover effect ultimate can create circular shapes and it’ll appear more often as design elements in their websites. Overall, you’ll have the full control of your image hover item when using the awesome Image Hover Effects Ultimate– Captions Hover with Visual Composer plugin.

**Square Effects** Square Effects of image hover was designed for getting the square effects very easily. We let there a bunch of choice for your selection convenience. You can choose your preferred square effect from 21 different square effect types here. Each effect contains different layout that will add more diversity to your image/caption hover item. You can set the effect direction as you want with this effect. Moreover, you can customize the basic same tools that you’ve been probably used on another effect type at once. This is a great convenience as a developer who basically likes variations.

**Button Effects** This is the last effect type and also a unique separate effect in image hover plugins at WordPress. You probably want some icon to show on your image to add the social sharing button. Here with these effects types you can add social icon button to making the link to your image. For the link and zoom image buttons integrated advanced icon selector with a library of the hundred icons in this Button Effects. Every image button has fully customizable color settings for borders, hover, backgrounds, and icon colors of the image hover effect. Different for static and hovered gallery buttons. You can add a maximum of 2 icons on each image.

**Hover Background Image** This is a special option we’ve developed at our newer version of Image Hover Effects Ultimate– Captions Hover with Visual Composer plugin. You can customize the background image for the image hover. It can be a different image or color preset. All you want to do with your image hover background here we left every control to you.


=Most Powerful Features=

Image Hover Effects Ultimate very professional image hover plugin. It has an amazing transition effects, sequence of the other images: Fade, Cross Fade, Slide, Slideshow, Slice, Blinds, 3D, 3D Horizontal, Horizontal, Vertical, Blocks and Shuffle. Over time, we will add new effects on our plugin by the update to update. Image Hover Effects Ultimategives to image unique look and beautiful design. Animation options allow adding different transition effects for the responsive image hover. Image Hover Effect will give a unique look to your photos, with its descriptions and titles which also has their own animation effects. Image Hover Effects Ultimate– Captions Hover with Visual Composer is very Powerful and Simple Image Hover Effect Creation WordPress Plugin. You can add hover effect to multiple images with unique customization in each, also you can insert some caption hover in your WordPress page. By using WordPress backend, you can create as much as you want and by using a short code, insert it into your posts and pages.

+ **Multiple Image Hover Effects or Caption Hover** Create Multiple Image Hover Effects or Captions with these awesome plugins where you can add Second Image on Hover. Also change the Background Opacity to make more affordable to your Users. It is a developer based plugin so users are allowed to add some customize option where they like to add more option on image hover if they like to add. Kindly inform us if you like to add anything.  Insert Your Image on Your Website with simple and flexible way by using our interactive and modern image hover effects ultimate plugins. It’s Fast to Configure and easy to use and has a bunch of setting and options to setup as per as you need.

+ **Portfolio Image Hover Gallery** Images gallery, it’s a better form to represent your portfolio on your website. With Image Hover Effects Ultimate, you can easily build your portfolio with image galleries by adding multiple image hover on every row of the page. You can get a gallery look with our plugin. Every image could have different settings. You can create absolutely different image hover on your page which fit to your needs and design the best way.

+ **Beautiful Hover Effects** Image Hover makes displaying your image a beautiful experience, by using amazing hover effects ranging from slicing and sliding to fading and fading. There simply is no better way to showcase your amazing work than to make the presentation of it looks just as beautiful.

+ **Image Borders and Shadows** All borders and shadows of the image hover have multiplied configuration options. You can fully customize size, color, transparency of the image hover interface. Shadow also has additional blur option for image hover shadow. All options could be configured with an image hover control or defined values manually in edit fields of the image hover effect options.

+ **Styling Text of the Image Content** All text on the Image Hover could be styled in the backend. For title and description of the images we have advanced settings for customization of the font. We’ve designed separate section for customizing the typography stuffs. You can select font style, size and colors for the static and hovered text of the image hover elements.

+ **Icons Library** For link and zoom the button on Image Hover integrated advanced icon selector with a library of the hundred icons. We have a special effect section for the button effects. Every button has fully customizable color settings for borders, backgrounds, icon.

+ **Color Pickers** For all images hover elements implemented very comfortable color picker. With color picker option, you can define color multiply ways. For every image you can select transparency for the color. Colors could be defined in HEX or RGB style.

+ **Advanced Media Manager** Upload of the images into the page implemented with advanced drag and drop media manager. The image Hover media manager has a wide set of the options for sorting images, crop, rotate, flip, scale of the original gallery image.


**Image Hover Live Demo**

**Image Hover Effects Ultimate** an exceptional plugin with a bunch of tools and options which are very easy to add a hover effect to a web page. Within a few minutes one developer can add multiple image hover effect on their site. It is very easy to set up and very simple to add unlimited categories and Shortcode during create hover effect. Users will find unlimited color option and each Circle Effects with 4 Animation in free version. With this vantage users can make a hover item slide out, change and animate the background color of the item and then get slide the elements back in with a different color. 

The number of the **image hover effects** for each image is not limited. Various layers can be applied to each individual responsive item. There are three basic types of layers designed for the image hover. Those are for sharing textual content, images and sharing buttons (Google+, Tumblr, Twitter, Pinterest and Facebook.) The Image hover can be used for redirection to another location. Similar feature is also available with the text and image layers of WordPress hover effect plugin.

>  Your suggestions will make this plugin even better, so  [let us know ](https://wordpress.org/support/plugin/image-hover-effects-ultimate#new-post "let us know") if you need any assistance or help.

Image Hover Effects Ultimate contains 150+ hover effect styles. You can find more variations in the effects. If you aren’t sure which one is perfect for you using then you can take a look at our live demo section. Here you can see all Effects style live demo. You can find that demo at our official website or at the live plugin interface. You also can pick directly from those effects. We’ve designed our plugin very user-friendly and handy to use this kind of features.


== Installation ==

We’ve made it very simple and very easy to use. The installation process of this plugin is very easy. Those who are not even a regular user or even haven’t any prior experience can easily install our product on their WP dashboard. Nevertheless, for your convenience, we left an installation instruction over here: 

> =Option 1=
> + Download the plugin image-hover-effects-ultimate.zip from WordPress Plugin Directory.
> + Unzip the zip file and extract the plugin folder named <strong>image-hover-effects-ultimate.zip
> + Left that plugin folder into your wp-content/plugins folder.
> + Go and refresh your Wordpress administration panels and from the menu bar click on Plugins.
> + Now you may see your plug-in listed under inactive plug-in tab.
> + Click active to turn your wordpress plugin on.

> =Option 2=
> + Like the first option you have to download the zip file from download location.
> + Unzip the zip file and extract the Image Hover Effects Ultimate plugin folder.
> + Double click on the installable folder in order to get image-hover-effects-ultimate.zip.
> + Go to wordpress admin panel and press Add New from the Menu bar under plugins tab.
> + Select upload link and drug the available image Hover Effects Plugin file and click install now.
> + After successfully installed finally click on ‘activate’ to turn on.

Let us know if you need any help, just open a thread into Support Forum. Don’t be hesitated to inform us about any Bugs or Conflict. 

=Product Activation License=

On the Image Hover Effects Ultimate submenu, you’ll find a new option entitled “Product License”. Here you can Upgrade your free version plugin to Pro version. By submitting and activating the license key you’ll able to upgrade your plugin very easily from this option. Let’s see how to upgrade the plugin from Product License submenu.

Go to Product License submenu>> Enter the Product Key>> Click Save Changes button>> Now click on Activate license. That’s all! Now within few minutes you will get update notification to update your plugins. After Update you are able to access Pro features.

**How to Start with Image Hover Effect Ultimate**

We make Image Hover Effect Ultimate WordPress plugin very user friendly so that users can use it without having any trouble, rather they will find interest in it. Creating hovers item on an image is very simple and intuitive here with Image Hover Effect Ultimate. Also, the admin area of Image hovers effect ultimate contains inline information that describes you the settings and possibilities that the Image hover effect ultimate plugin offers. In this part we’re going to give you some instruction on how to start adding hover item to Image hover effect. So, let’s start:

> + Click the Image Hover Effects Ultimate submenu entry entitled “General Effects”. This will take you to the image hover effect creation and editing page.
> + Now select a Style from our template list. 
> + After selecting a style you’ll need to create a name of your selected style. Now click the Save button.
> + Now click on Add New Items and upload a valid image. 

At this point you will see the Hover Modification Form with 6 Field

> + First field: "Your Title" You can enter any title, the important thing to remember is that the item width and height are limited so please enter a short title. This is important to maintain the layout of the image wrapper.
> + Second field: "Your Description" You can quickly insert the description in the description text area. It is important to enter a short description to maintain the layout of the image wrapper.
> + Third field: "Enter URL" Chose a button URL in this field. EX: https://www.oxilab.org
> + Forth Field: “Bottom Text” adds bottom text here.
> + Fifth Field: "Upload Image" to choose an image, the image can come from any source and be any size, you can also use images uploaded right from the post media Uploader. Just copy the URL of the image after you upload it.
> + Sixth Field: “Hover Background Image” Here you can add an image for the hover background of the image.

**Note** Remember that you have to add a valid button URL (EX: http://google.com).

After adding a style and upload an image for making hovered item you can generate the shortcodes to your site post or page. Follow these instructions below:

> + Go to Dashboard.
> + Click Add New Post or page. 
> + In your Post/Page Editor you will see a Black down arrow box within your editor.
> + Put Any Title On Title field.
> + Copy & Paste the Shortcode from the plugin.
> + Click Publish.

=Customizable=

Your WordPress website represents you, your brand or your company. Image Hover Effects Ultimate allows you to create your plugin, exactly as you would like. You can customize the selection and settings of color, background, borders and edges, and more. The editing interface of General Effects contains four different customizing sections. There are general, heading, description and button text modification section. Let’s discuss more about the settings of those sections…


=General Settings=
> + **Image per Row** Here you can select the image number you want to show in a single row of the page. You can add highest 6 items per row. This will give you the extra convenience to work with multiple images on one page.
> + **Image Radius** Image Radius allows you to customize the image type. You can get a rounded shape image by increasing the value. With 50% radius value you can get a circle image. And if you need a full square image customize that here.
> + **Image Width & Height** You can customize the image width and height here.
> + **Image Margin** Image Margin is designed for making the distance between image to image. The proper setting of this option your image hover gallery will have more attractive and neat look.
> + **Content Padding** This padding option is for generating the space around the image content.
> + **Background** This option is for those who don’t want to upload any image to set as hover background. They can pick a color for their image hover background in this option. 
> + **Content Alignment** You can customize the aligning option of the image content here.
> + **Open in New Tab** Here you can set the direction of your image link opening. Whether you can set the link to open in a new tab or the existing tab. 
> + **Image Animation** You can select the animation style of your image hover. Here we left the bounce, fade in, flippers, light speed, rotation entrance, sliding entrance, zoom entrance and some special style effect. 
> + **Animation Duration** Here you can set the timing of the animation. You can choose the animation duration here with this option.  
> + **Content Animation** Like image animation you are able to add and customize the animation for the content. This option will allow you to choose the animation style for image hover content.
> + **Inner Shadow** Add some shadow to the image inner portion with this option. This feature will help you to make your image more attractive and colorful. 
> + **Inner Shadow Color** Give some color to your image inner shadow to make the shadow visible to the viewers.


=Heading Setting=

> + **Font Size** This option will help you to customize the font size of the content heading. You can customize the heading font size of the image hover with this option.
> + **Font Color** You can choose a color for the font from the color picker in this option. 
> + **Font Family** You can use Google font-family to add your preferred font for the heading. Creating all this you will have the original Image Hover with pretty content. 
> + **Font Weight** Font weight is for customizing the weight style of the heading font. This is a free feature for decoration the image hover content heading.
> + **Heading Underline** By customizing the font style you can make your image content look more attractive. Heading Underline will add the heading an extra new look and also give the text some focus. 
> + **Padding Bottom** By generating the space between the heading content and underline you can decorate the heading much prettier.
> + **Margin Bottom** This option is for creating the margin to having some space between heading text and description text. Like padding bottom this option is also a free option.

=Description Settings=

> + **Font Size** This option will help you to customize the font size of the content description. You can customize the description font size of the image hover with this option. 
> + **Font Color** You can choose a color for the description text from the color picker in this option. 
> + **Font Family** You can use Google font-family to add your preferred font for the description text. Creating all this you will have the original Image Hover with pretty content. 
> + **Font Weight** Font weight is for customizing the weight style of the description text. This is a free feature for decoration the image hover content description.
> + **Padding Bottom** By generating the space between the description content and bottom text you can decorate the image hover content section much prettier.


=Button Text Settings=

> + **Font Size** This option will help you to customize the font size of the content button text. You can customize the button text font size of the image hover with this option. 
> + **Font Color** You can choose a color for the button text from the color picker in this option. 
> + **Font Family** You can use Google font-family to add your preferred font for the button text. Creating all this you will have the original Image Hover with pretty content. 
> + **Background Color** This option is for customizing the background color of the button text. You can select a color balancing out the hover background color, opacity and the opacity of the button text. 
> + **Font Weight** Font weight is for customizing the weight style of the button text. This is a free feature for decoration the image hover content button.
> + **Hover Color** When you hover over the button the color you select from this option will be appeared on the image. This option is for customizing the hover color of the button text. 
> + **Hover Background** You can customize the hover background color of the button text here. 
> + **Button Radius** If you want to give a rounded shape to your image button then increase the value here. This is a free version feature.
> + **Padding Top Bottom** To make a bigger or smaller button, customers the Padding top bottom option. This will increase the space at the top, bottom side of the button.
> + **Padding Left, Right** To make a bigger or smaller button, customize the Padding left right option. This will increase the space at the left and right side of the button.
> + **Button Align** Customize the button alignment to accurate the button text position in your image. Set the relevant position in the image.


== Frequently Asked Questions ==

WordPress image hover effects Ultimate - Caption Hover with Visual Composer Plugin

= Whether, is the Image hover Effects support basic HTML Elements? =

Yes. Basic Html has a support possibility.Such as you can add </br>,  <strong> .

= Is the Image Hover Effects Ultimate - Captions Hover with Visual Composer Responsive? =

Yes, reacts and displays resizing images, videos, titles and descriptions for mobile devices and tablets.

= How to enable the Image hover effects ultimate to in a post or page? =

[iheu_ultimate_oxi id="1"] as demo for post. You can also add into page as shortcode for page.

=Is Image Hover Effects Support Page Builder

Yes, On Page Builder you Use shortcode for page builder. We also add extension for Visual Composer and SiteOrgin.

= Do i Make Clone of any Style

Its too easy Chose your style from Effects List and click at Clone.


== Screenshots ==

1. Image hover Template Demo
2. Visual Composer Add element.
2. Admin panel With Live Preview.
3. Popup Data Input form.


== Changelog ==
= 9.2 = 
*Fixed Bugs 

= 9.1 = 
*Fixed Bugs with page builders

= 9.0 = 
*Fixed Bugs with Update Admin

= 8.9 = 
*Fixed with Gutenberg

= 8.8 = 
*Fixed Bugs
*Added Font Awesome upto 7.1

= 8.7 = 
*Fixed Bugs

= 8.6 = 
*Fixed Bugs
*Added Font Awesome 5.5

= 8.5 = 
*Fixed Bugs

= 8.4 = 
*Fixed Bugs

= 8.3 = 
*Update font Awesome
*Add image Rearrange Options

= 8.2 = 
*Solved Some Responsive Data.
*Add Mobile or Touch Device Behavior  

= 8.1 = 
*Add License Option.
*User Capabilities 

= 8.0 = 
*Customize Responsive Data.

= 7.5 = 
*Resolved Bugs.

= 7.5 = 
*Solved Bugs.

= 7.4 = 
*Solved Bugs.

= 7.3 = 
*Solved Bugs.
*Work with Touch Screen Device
*Documentation publish

= 7.2 = 
*Add hover Second Image

= 6.9.1 = 
*Solved image Problem

= 6.9 = 
*Added 150+ Image Hover

= 6.8.2 = 
*Resolve Bugs

= 6.8.1 = 
* Add more Options

= 6.7.1 = 
* Add Visual Composer Options

= 6.7 = 
* Update Admin Panel


= 6.6 = 
* Fixed some Bugs


= 6.5 = 
* Fixed some Bugs

= 6.4 = 
* Fixed some Bugs
* Responsive options

= 6.0 = 
* Add More Options
* Complete Responsive options

= 4.0 = 
* Fixed some Bugs

= 4.0 = 
* Added Bottom text option
* Added Without link Image hover

= 3.0 = 
* Added more Options
* Fixed some Bugs

= 2.0 = 
* Update pro version
* improve admin panel

= 1.0 =
* Initial Release
* responsive layout


== Upgrade Notice ==
= 9.2 = 
Fixed bugs

= 9.1 = 
Fixed bugs with Page builders

= 9.0 = 
Update Admin

= 8.9 = 
Fixed with Gutenberg

= 8.8 = 
Fixed Bugs
Added Font Awesome upto 7.1

= 8.7 = 
Fixed Bugs

= 8.6 = 
Fixed Bugs
Added Font Awesome 5.5

= 8.5 = 
Fixed Bugs

= 8.4 = 
Fixed Bugs

= 8.3 = 
Update font Awesome
Add image Rearrange Options

= 8.2 = 
Solved Some Responsive Data.
Add Mobile or Touch Device Behavior  

= 8.1 = 
Add License Option.
User Capabilities 

= 8.0 =
Added Responsive Data.

= 7.6 =
Resolve Bugs.

= 7.5 =
Upgrade to Resolve Viewport Capable Hover effects.

= 7.4 =
Upgrade to Resolve Touchscreen Device Capable Hover effects.

= 7.3 =
Upgrade to Resolve Touchscreen Device Capable Hover effects. Also Solved some responsive bugs. 
