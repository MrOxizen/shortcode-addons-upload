<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * Edit By Sabibur Rahman
 */

return array('2.0.0', '3rd Party Widgets', true, 'far fa-address-card');