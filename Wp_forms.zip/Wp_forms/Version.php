<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * Checked by Fuad
 */

return array('2.0.0', '3rd Party Widgets', true, 'fab fa-wpforms');
