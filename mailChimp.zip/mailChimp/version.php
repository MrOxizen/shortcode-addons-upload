<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5.3
 */

return array(1.6, 'Form Contents', true);
