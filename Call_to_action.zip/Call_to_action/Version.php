<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * checked by Al-alamin
 */

return array('2.0.0', 'Marketing Elements', true, 'fas fa-street-view');
