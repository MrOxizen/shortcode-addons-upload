<?php
/*
  Plugin Name: Shortcode Addons
  Version: 2.0.0
 * Checked by Fuadia
 */

return array('2.0.0', 'Image Effects', true, 'fas fa-image', true);
