<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 * Checked by - Al-amin
 */

return array('2.0.0', 'Content Elements', true,'far fa-images', false);
